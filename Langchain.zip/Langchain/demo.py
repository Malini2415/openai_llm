import langchain
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain import OpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import DirectoryLoader
# import magic
import os
import nltk
# pip install langchain --upgrade
# Version: 0.0.164

# !pip install pypdf
# PDF Loaders. If unstructured gives you a hard time, try PyPDFLoader
from langchain.document_loaders import UnstructuredPDFLoader, OnlinePDFLoader, PyPDFLoader

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma, Pinecone
from langchain.embeddings.openai import OpenAIEmbeddings
import pinecone
from langchain.llms import OpenAI
from langchain.chains.question_answering import load_qa_chain
import os
loader = DirectoryLoader('C:/Users/malini.duraisamy/Desktop/Langchain/model', glob='**/*.pdf')
data = loader.load()

# directory_path = 'C:/Users/malini.duraisamy/Desktop/Langchain/model'
# file_extensions = ['pdf', 'csv', 'txt']

# # Create the DirectoryLoader with the updated glob parameter
# loader = DirectoryLoader(directory_path, glob='**/*.' + '|'.join(file_extensions))
# Note: If you're using PyPDFLoader then we'll be splitting for the 2nd time.
# This is optional, test out on your own data.

text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=0)
texts = text_splitter.split_documents(data)

pinecone.init(api_key="3f879b2f-0f70-4b4e-97a0-8ff0a5ee9fe8", environment="northamerica-northeast1-gcp")

# Check to see if there is an environment variable with you API keys, if not, use what you put below
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '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')

PINECONE_API_KEY = os.environ.get('PINECONE_API_KEY', '3f879b2f-0f70-4b4e-97a0-8ff0a5ee9fe8')
PINECONE_API_ENV = os.environ.get('PINECONE_API_ENV', 'northamerica-northeast1-gcp') # You may need to switch with your


embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)

# initialize pinecone
pinecone.init(
    api_key=PINECONE_API_KEY,  # find at app.pinecone.io
    environment=PINECONE_API_ENV  # next to api key in console
)
index_name = "orbito360-demo" # put in the name of your pinecone index here

docsearch = Pinecone.from_texts([t.page_content for t in texts], embeddings, index_name=index_name)

llm = OpenAI(temperature=0, openai_api_key=OPENAI_API_KEY)
chain = load_qa_chain(llm, chain_type="stuff")

query = "what is the type of this document"
docs = docsearch.similarity_search(query)


response=chain.run(input_documents=docs, question=query)

print(response)
