from flask import Flask, request, render_template
from langchain.document_loaders import DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.document_loaders import (
    CSVLoader,
    EverNoteLoader,
    PyMuPDFLoader,
    TextLoader,
    UnstructuredEmailLoader,
    UnstructuredEPubLoader,
    UnstructuredHTMLLoader,
    UnstructuredMarkdownLoader,
    UnstructuredODTLoader,
    UnstructuredPowerPointLoader,
    UnstructuredWordDocumentLoader,
)
from langchain.docstore.document import Document
from langchain.vectorstores import Pinecone
from langchain.llms import OpenAI
from langchain.chains.question_answering import load_qa_chain
from flask import Flask, request, redirect, url_for, flash, render_template
from flask import Flask,jsonify,request
import os
import shutil
import pinecone
import flask
import zipfile
import glob
from waitress import serve

from typing import List

from multiprocessing import Pool
from tqdm import tqdm

ALLOWED_EXTENSIONS = set(['zip'])
# chunk_size = 2000
# chunk_overlap = 0
chunk_size = 500
chunk_overlap = 50


app = Flask(__name__)
app.secret_key = 'langchain'


text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=0)

# Initialize Pinecone
PINECONE_API_KEY = os.environ.get('PINECONE_API_KEY', '3f879b2f-0f70-4b4e-97a0-8ff0a5ee9fe8')
PINECONE_API_ENV = os.environ.get('PINECONE_API_ENV', 'northamerica-northeast1-gcp')
pinecone.init(api_key=PINECONE_API_KEY, environment=PINECONE_API_ENV)
index_name = "orbito360-demo"  # Put in the name of your Pinecone index here

# Initialize OpenAI
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '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')
embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
llm = OpenAI(temperature=0, openai_api_key=OPENAI_API_KEY)
chain = load_qa_chain(llm, chain_type="stuff")

# Define the docsearch variable globally
docsearch = None


def get_directory_paths(root_directory):
    directory_paths = []
    for dirpath, dirnames, filenames in os.walk(root_directory):
        for dirname in dirnames:
            directory_paths.append(os.path.join(dirpath, dirname))
    return directory_paths

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS





# Custom document loaders
class MyElmLoader(UnstructuredEmailLoader):
    """Wrapper to fallback to text/plain when default does not work"""

    def load(self) -> List[Document]:
        """Wrapper adding fallback for elm without html"""
        try:
            try:
                doc = UnstructuredEmailLoader.load(self)
            except ValueError as e:
                if 'text/html content not found in email' in str(e):
                    # Try plain text
                    self.unstructured_kwargs["content_source"]="text/plain"
                    doc = UnstructuredEmailLoader.load(self)
                else:
                    raise
        except Exception as e:
            # Add file_path to exception message
            raise type(e)(f"{self.file_path}: {e}") from e

        return doc


# Map file extensions to document loaders and their arguments
LOADER_MAPPING = {
    ".csv": (CSVLoader, {}),
    # ".docx": (Docx2txtLoader, {}),
    ".doc": (UnstructuredWordDocumentLoader, {}),
    ".docx": (UnstructuredWordDocumentLoader, {}),
    ".enex": (EverNoteLoader, {}),
    ".eml": (MyElmLoader, {}),
    ".epub": (UnstructuredEPubLoader, {}),
    ".html": (UnstructuredHTMLLoader, {}),
    ".md": (UnstructuredMarkdownLoader, {}),
    ".odt": (UnstructuredODTLoader, {}),
    ".pdf": (PyMuPDFLoader, {}),
    ".ppt": (UnstructuredPowerPointLoader, {}),
    ".pptx": (UnstructuredPowerPointLoader, {}),
    ".txt": (TextLoader, {"encoding": "utf8"}),
    # Add more mappings for other file extensions and loaders as needed
}


def load_single_document(file_path: str) -> List[Document]:
    ext = "." + file_path.rsplit(".", 1)[-1]
    if ext in LOADER_MAPPING:
        loader_class, loader_args = LOADER_MAPPING[ext]
        loader = loader_class(file_path, **loader_args)
        return loader.load()

    raise ValueError(f"Unsupported file extension '{ext}'")

def load_documents(source_dir: str, ignored_files: List[str] = []) -> List[Document]:
    """
    Loads all documents from the source documents directory, ignoring specified files
    """
    all_files = []
    for ext in LOADER_MAPPING:
        all_files.extend(
            glob.glob(os.path.join(source_dir, f"**/*{ext}"), recursive=True)
        )
    filtered_files = [file_path for file_path in all_files if file_path not in ignored_files]

    with Pool(processes=os.cpu_count()) as pool:
        results = []
        with tqdm(total=len(filtered_files), desc='Loading new documents', ncols=80) as pbar:
            for i, docs in enumerate(pool.imap_unordered(load_single_document, filtered_files)):
                results.extend(docs)
                pbar.update()

    return results



# Set up document loader and text splitter
# loader = DirectoryLoader('C:/Users/malini.duraisamy/Desktop/Langchain/model', glob='**/*.pdf')


# @app.route('/')
# def home():
#     return render_template('index.html')

# directories = ['model']
# for directory in directories:
#     if os.path.exists(directory) and os.path.isdir(directory):
#             # Delete the folder and its contents
#             shutil.rmtree(directory)  
#     print('Folders deleted successfully')


@app.route('/upload', methods=['GET', 'POST'])
def upload_file(ignored_files: List[str] = []) -> List[Document]:
    global docsearch  # Make the docsearch variable accessible globally
    if flask.request.method == 'GET' :
        return jsonify({'Error' : "Failed. Invoke Post Method"})
    else:
        # check if the post request has the file part
        if 'model' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['model']
    
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            directories = ['model']
            for directory in directories:
                if os.path.exists(directory) and os.path.isdir(directory):
                        # Delete the folder and its contents
                        shutil.rmtree(directory)  
                print('Folders deleted successfully')



            basepath = os.path.dirname(__file__)
            folder_path = os.path.join(basepath, 'upload_folder')
    
            # Create the 'upload_folder' if it doesn't exist
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            
            # Save the uploaded file to the 'upload_folder'
            file = request.files['model']
            filepath = os.path.join(folder_path, file.filename)
            # file.save(filepath)
            print("upload folder is ", filepath)
            file.save(filepath)
            
            zip_ref = zipfile.ZipFile(filepath, 'r')
            zip_ref.extractall(basepath)
            zip_ref.close()

            if os.path.exists(filepath):
                os.remove(filepath)

            root_directory = os.path.join(basepath, 'model')
            if not os.path.exists(root_directory):
                os.makedirs(root_directory) 

            # root_directory = os.path.join(basepath, 'model')
            # if not os.path.exists(root_directory):
            #     print("The 'model' directory does not exist. Please create it and try again.")
            #     return "Error: 'model' directory not found"
            # loader = DirectoryLoader(root_directory, glob='**/*.pdf')
            # loader = DirectoryLoader(root_directory, glob='**/*.pdf|**/*.csv|**/*.txt')
            print(f"Loading documents from {root_directory}")
            
            documents = load_documents(root_directory, ignored_files)
            if not documents:
                print("No new documents to load")
                exit(0)
            print(f"Loaded {len(documents)} new documents from {root_directory}")
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
            texts = text_splitter.split_documents(documents)
            print(f"Split into {len(texts)} chunks of text (max. {chunk_size} tokens each)")
            # docsearch = Pinecone.from_texts([t.page_content for t in texts], embeddings, index_name=index_name)
        # # Load and split the document
        #     data = loader.load()
        #     texts = text_splitter.split_documents(data)
            
            # Index the document in Pinecone
            docsearch = Pinecone.from_texts([t.page_content for t in texts], embeddings, index_name=index_name)
            
            return "Model uploaded successfully ,Now you can ask your Query!"
        
        return "No file uploaded."

@app.route('/', methods=['GET', 'POST'])
def process_query():
    global docsearch  # Make the docsearch variable accessible globally
    if flask.request.method == 'GET' :
        return jsonify({'Error' : "Failed. Invoke Post Method"})
    else:
    
        query = request.form['query']
        if query and docsearch:
            # Search for similar documents in Pinecone
            docs = docsearch.similarity_search(query)
            
            # Perform question answering
            response = chain.run(input_documents=docs, question=query)
            
            return response
        
        return "No query provided or document not uploaded yet."

if __name__ == '__main__':
    serve(app, host="0.0.0.0", port=8080)
